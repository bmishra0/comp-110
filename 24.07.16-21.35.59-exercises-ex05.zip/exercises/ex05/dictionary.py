"""The some practice with dictionary."""

__author__ = "730644820"


def invert(d: dict[str, str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for key, value in d.items():
        invert[value] = key
    return result
