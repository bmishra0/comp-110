"""These are the test for the dictionary."""

__author__ = "730644820"

from exercises.ex05.dictionary import invert


def test_invert_edge() -> None:
    assert invert([], []) == []
